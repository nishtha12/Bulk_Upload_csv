//package com.example.demo.Entity;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Table;
//
//@Entity
//@Table(name = "answer")
//public class Answer {
//    @Column(name="answer_mcq")
//    String answermcq;
//    @Column(name="answer_text")
//    String answertext;
//
//    @Override
//    public String toString() {
//        return "Answer{" +
//                "answermcq='" + answermcq + '\'' +
//                ", answertext='" + answertext + '\'' +
//                '}';
//    }
//
//    public String getAnswermcq() {
//        return answermcq;
//    }
//
//    public void setAnswermcq(String answermcq) {
//        this.answermcq = answermcq;
//    }
//
//    public String getAnswertext() {
//        return answertext;
//    }
//
//    public void setAnswertext(String answertext) {
//        this.answertext = answertext;
//    }
//
//    public Answer(String answermcq, String answertext) {
//
//        this.answermcq = answermcq;
//        this.answertext = answertext;
//    }
//}
